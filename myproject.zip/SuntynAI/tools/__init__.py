
# Tools package
from .tool_processor import ToolProcessor

# Create a global processor instance
processor = ToolProcessor()
